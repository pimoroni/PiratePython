# New canonical package, to support `import rpi_ws281x`
from .rpi_ws281x import PixelStrip, Adafruit_NeoPixel, Color

__version__ = '3.0.3'
