# Included for backwards-compatibility with old import name
from rpi_ws281x import __version__, PixelStrip, Adafruit_NeoPixel, Color
